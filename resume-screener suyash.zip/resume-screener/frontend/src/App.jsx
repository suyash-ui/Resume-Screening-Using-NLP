import { useState, useCallback, useRef } from "react";
import axios from "axios";

const API = "http://localhost:8000";

const CATEGORY_ICONS = {
  "Data Science": "🧠",
  "Java Developer": "☕",
  "Python Developer": "🐍",
  "Web Designing": "🎨",
  "HR": "👥",
  "Testing": "🧪",
  "DevOps Engineer": "⚙️",
  "Hadoop": "🐘",
  "Sales": "📈",
  "Mechanical Engineer": "🔧",
  "ETL Developer": "🔄",
  "Arts": "🎭",
  "Database": "🗄️",
  "Health and Fitness": "💪",
  "PMO": "📋",
  "Electrical Engineering": "⚡",
  "Business Analyst": "📊",
  "DotNet Developer": "🔷",
  "Automation Testing": "🤖",
  "Network Security Engineer": "🔒",
  "Civil Engineer": "🏗️",
  "SAP Developer": "💼",
  "Advocate": "⚖️",
  "Blockchain": "🔗",
  "Operations Manager": "🏢",
};

function App() {
  const [activeTab, setActiveTab] = useState("text");
  const [resumeText, setResumeText] = useState("");
  const [file, setFile] = useState(null);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [dragOver, setDragOver] = useState(false);
  const [apiMode, setApiMode] = useState(null);
  const fileInputRef = useRef();

  const handlePredict = useCallback(async () => {
    setError(null);
    setResult(null);
    setLoading(true);

    try {
      let res;
      if (activeTab === "text") {
        if (!resumeText.trim()) {
          setError("Please paste your resume text first.");
          setLoading(false);
          return;
        }
        res = await axios.post(`${API}/predict/text`, { text: resumeText });
      } else {
        if (!file) {
          setError("Please select a file first.");
          setLoading(false);
          return;
        }
        const form = new FormData();
        form.append("file", file);
        res = await axios.post(`${API}/predict/file`, form, {
          headers: { "Content-Type": "multipart/form-data" },
        });
      }
      setResult(res.data);
      setApiMode(res.data.mode);
    } catch (err) {
      const msg = err?.response?.data?.detail || err.message || "Prediction failed";
      setError(msg);
    } finally {
      setLoading(false);
    }
  }, [activeTab, resumeText, file]);

  const handleDrop = useCallback((e) => {
    e.preventDefault();
    setDragOver(false);
    const dropped = e.dataTransfer.files[0];
    if (dropped) setFile(dropped);
  }, []);

  const confidenceColor = (conf) => {
    if (conf >= 0.85) return "#00e5a0";
    if (conf >= 0.65) return "#f59e0b";
    return "#f87171";
  };

  const confidenceLabel = (conf) => {
    if (conf >= 0.85) return "High Confidence";
    if (conf >= 0.65) return "Medium Confidence";
    return "Low Confidence";
  };

  return (
    <div style={styles.root}>
      {/* Background grid */}
      <div style={styles.bgGrid} />

      {/* Header */}
      <header style={styles.header}>
        <div style={styles.headerInner}>
          <div style={styles.logo}>
            <span style={styles.logoIcon}>⬡</span>
            <span style={styles.logoText}>ResumeIQ</span>
          </div>
          <div style={styles.badge}>
            {apiMode === "ml" ? "🟢 ML Mode" : apiMode === "demo" ? "🟡 Demo Mode" : "⚪ Ready"}
          </div>
        </div>
      </header>

      {/* Hero */}
      <section style={styles.hero}>
        <p style={styles.heroTag}>NLP + Machine Learning</p>
        <h1 style={styles.heroTitle}>
          Resume<br />
          <span style={styles.heroAccent}>Screening</span><br />
          Intelligence
        </h1>
        <p style={styles.heroSub}>
          Classify any resume into 25 professional categories using TF-IDF vectorization and Support Vector Classification.
        </p>
      </section>

      {/* Main Panel */}
      <main style={styles.main}>
        <div style={styles.card}>
          {/* Tabs */}
          <div style={styles.tabs}>
            {["text", "file"].map((t) => (
              <button
                key={t}
                onClick={() => { setActiveTab(t); setResult(null); setError(null); }}
                style={{
                  ...styles.tab,
                  ...(activeTab === t ? styles.tabActive : {}),
                }}
              >
                {t === "text" ? "📝 Paste Text" : "📁 Upload File"}
              </button>
            ))}
          </div>

          {/* Input */}
          <div style={styles.inputSection}>
            {activeTab === "text" ? (
              <textarea
                style={styles.textarea}
                placeholder="Paste resume content here…&#10;&#10;Include skills, experience, education, and any relevant keywords to get the most accurate classification."
                value={resumeText}
                onChange={(e) => setResumeText(e.target.value)}
                rows={12}
              />
            ) : (
              <div
                style={{ ...styles.dropzone, ...(dragOver ? styles.dropzoneActive : {}) }}
                onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                onDragLeave={() => setDragOver(false)}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".pdf,.docx,.txt"
                  style={{ display: "none" }}
                  onChange={(e) => setFile(e.target.files[0])}
                />
                {file ? (
                  <div style={styles.fileChosen}>
                    <span style={styles.fileIcon}>
                      {file.name.endsWith(".pdf") ? "📄" : file.name.endsWith(".docx") ? "📝" : "📃"}
                    </span>
                    <div>
                      <div style={styles.fileName}>{file.name}</div>
                      <div style={styles.fileSize}>{(file.size / 1024).toFixed(1)} KB</div>
                    </div>
                    <button
                      style={styles.clearFile}
                      onClick={(e) => { e.stopPropagation(); setFile(null); setResult(null); }}
                    >✕</button>
                  </div>
                ) : (
                  <div style={styles.dropContent}>
                    <span style={styles.dropIcon}>⬆</span>
                    <p style={styles.dropText}>Drop your resume here or click to browse</p>
                    <p style={styles.dropHint}>Supports PDF, DOCX, TXT</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Stats bar */}
          {activeTab === "text" && resumeText && (
            <div style={styles.statsBar}>
              <span>📊 {resumeText.split(/\s+/).filter(Boolean).length} words</span>
              <span>📝 {resumeText.length} chars</span>
              <span style={{ color: resumeText.length >= 50 ? "#00e5a0" : "#f87171" }}>
                {resumeText.length >= 50 ? "✓ Sufficient length" : "⚠ Too short"}
              </span>
            </div>
          )}

          {/* Error */}
          {error && (
            <div style={styles.errorBox}>
              <span>⚠️</span> {error}
            </div>
          )}

          {/* Submit */}
          <button
            style={{ ...styles.btn, ...(loading ? styles.btnDisabled : {}) }}
            onClick={handlePredict}
            disabled={loading}
          >
            {loading ? (
              <span style={styles.spinner}>Analyzing resume…</span>
            ) : (
              "Classify Resume →"
            )}
          </button>
        </div>

        {/* Result */}
        {result && (
          <div style={styles.resultCard}>
            <div style={styles.resultHeader}>
              <span style={styles.resultIcon}>
                {CATEGORY_ICONS[result.category] || "🎯"}
              </span>
              <div>
                <div style={styles.resultLabel}>Predicted Category</div>
                <div style={styles.resultCategory}>{result.category}</div>
              </div>
            </div>

            <div style={styles.confidenceSection}>
              <div style={styles.confRow}>
                <span style={styles.confLabel}>Confidence</span>
                <span style={{ ...styles.confValue, color: confidenceColor(result.confidence) }}>
                  {(result.confidence * 100).toFixed(1)}% — {confidenceLabel(result.confidence)}
                </span>
              </div>
              <div style={styles.confBar}>
                <div
                  style={{
                    ...styles.confFill,
                    width: `${result.confidence * 100}%`,
                    background: confidenceColor(result.confidence),
                  }}
                />
              </div>
            </div>

            {result.top_predictions && result.top_predictions.length > 1 && (
              <div style={styles.altSection}>
                <div style={styles.altTitle}>Top Predictions</div>
                {result.top_predictions.map((p, i) => (
                  <div key={i} style={styles.altRow}>
                    <span>{CATEGORY_ICONS[p.category] || "•"} {p.category}</span>
                    <span style={styles.altScore}>{(p.score * 100).toFixed(1)}%</span>
                  </div>
                ))}
              </div>
            )}

            <div style={styles.metaRow}>
              {result.word_count && <span>📝 {result.word_count} words analyzed</span>}
              <span style={{
                background: result.mode === "ml" ? "#00e5a020" : "#f59e0b20",
                color: result.mode === "ml" ? "#00e5a0" : "#f59e0b",
                padding: "2px 10px", borderRadius: "20px", fontSize: "12px"
              }}>
                {result.mode === "ml" ? "🧠 ML Model" : "🔑 Keyword Engine"}
              </span>
            </div>
          </div>
        )}
      </main>

      {/* How it works */}
      <section style={styles.pipeline}>
        <h2 style={styles.pipelineTitle}>Pipeline Architecture</h2>
        <div style={styles.pipelineSteps}>
          {[
            { icon: "📄", label: "Input", desc: "Text / PDF / DOCX / TXT" },
            { icon: "🧹", label: "Clean", desc: "Regex noise removal" },
            { icon: "📊", label: "TF-IDF", desc: "7,353-term vectorization" },
            { icon: "🤖", label: "SVC", desc: "One-vs-Rest classifier" },
            { icon: "🎯", label: "Predict", desc: "25 job categories" },
          ].map((step, i) => (
            <div key={i} style={styles.pipelineStep}>
              <span style={styles.pipelineStepIcon}>{step.icon}</span>
              <div style={styles.pipelineStepLabel}>{step.label}</div>
              <div style={styles.pipelineStepDesc}>{step.desc}</div>
              {i < 4 && <div style={styles.pipelineArrow}>→</div>}
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer style={styles.footer}>
        <p>ResumeIQ · NLP Resume Screening System · Suyash's Black Book Project</p>
      </footer>
    </div>
  );
}

// ─── Styles ──────────────────────────────────────────────────────────────────

const styles = {
  root: {
    minHeight: "100vh",
    background: "#0a0b0f",
    color: "#e8eaf0",
    fontFamily: "'DM Sans', 'Inter', sans-serif",
    position: "relative",
    overflowX: "hidden",
  },
  bgGrid: {
    position: "fixed",
    inset: 0,
    backgroundImage: `
      linear-gradient(rgba(0,229,160,0.04) 1px, transparent 1px),
      linear-gradient(90deg, rgba(0,229,160,0.04) 1px, transparent 1px)
    `,
    backgroundSize: "48px 48px",
    pointerEvents: "none",
    zIndex: 0,
  },
  header: {
    position: "sticky",
    top: 0,
    zIndex: 10,
    background: "rgba(10,11,15,0.9)",
    backdropFilter: "blur(12px)",
    borderBottom: "1px solid rgba(255,255,255,0.07)",
    padding: "0 32px",
  },
  headerInner: {
    maxWidth: 960,
    margin: "0 auto",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    height: 60,
  },
  logo: { display: "flex", alignItems: "center", gap: 10 },
  logoIcon: { fontSize: 24, color: "#00e5a0" },
  logoText: { fontWeight: 700, fontSize: 18, letterSpacing: "-0.5px" },
  badge: {
    fontSize: 12,
    padding: "4px 12px",
    borderRadius: 20,
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.1)",
  },
  hero: {
    maxWidth: 960,
    margin: "0 auto",
    padding: "80px 32px 40px",
    position: "relative",
    zIndex: 1,
  },
  heroTag: {
    fontSize: 12,
    letterSpacing: "3px",
    textTransform: "uppercase",
    color: "#00e5a0",
    marginBottom: 16,
  },
  heroTitle: {
    fontSize: "clamp(40px, 7vw, 72px)",
    fontWeight: 800,
    lineHeight: 1.05,
    letterSpacing: "-2px",
    margin: "0 0 20px",
    color: "#f0f2f5",
  },
  heroAccent: { color: "#00e5a0" },
  heroSub: {
    fontSize: 16,
    color: "#8892a4",
    maxWidth: 500,
    lineHeight: 1.7,
  },
  main: {
    maxWidth: 960,
    margin: "0 auto",
    padding: "0 32px 60px",
    position: "relative",
    zIndex: 1,
    display: "flex",
    flexDirection: "column",
    gap: 24,
  },
  card: {
    background: "rgba(255,255,255,0.03)",
    border: "1px solid rgba(255,255,255,0.08)",
    borderRadius: 20,
    padding: 32,
    backdropFilter: "blur(8px)",
  },
  tabs: { display: "flex", gap: 8, marginBottom: 24 },
  tab: {
    padding: "10px 20px",
    borderRadius: 10,
    border: "1px solid rgba(255,255,255,0.1)",
    background: "transparent",
    color: "#8892a4",
    cursor: "pointer",
    fontSize: 14,
    fontWeight: 500,
    transition: "all 0.2s",
  },
  tabActive: {
    background: "#00e5a015",
    border: "1px solid #00e5a040",
    color: "#00e5a0",
  },
  inputSection: { marginBottom: 16 },
  textarea: {
    width: "100%",
    background: "rgba(255,255,255,0.03)",
    border: "1px solid rgba(255,255,255,0.1)",
    borderRadius: 12,
    color: "#e8eaf0",
    fontSize: 14,
    lineHeight: 1.7,
    padding: "16px",
    resize: "vertical",
    outline: "none",
    fontFamily: "inherit",
    boxSizing: "border-box",
    transition: "border-color 0.2s",
  },
  dropzone: {
    border: "2px dashed rgba(255,255,255,0.12)",
    borderRadius: 12,
    padding: 48,
    textAlign: "center",
    cursor: "pointer",
    transition: "all 0.2s",
  },
  dropzoneActive: {
    border: "2px dashed #00e5a0",
    background: "#00e5a008",
  },
  dropContent: {},
  dropIcon: { fontSize: 32, display: "block", marginBottom: 12, color: "#00e5a0" },
  dropText: { fontSize: 15, color: "#c8d0dc", margin: "0 0 6px" },
  dropHint: { fontSize: 12, color: "#5a6478", margin: 0 },
  fileChosen: {
    display: "flex",
    alignItems: "center",
    gap: 16,
    justifyContent: "center",
  },
  fileIcon: { fontSize: 36 },
  fileName: { fontWeight: 600, color: "#e8eaf0" },
  fileSize: { fontSize: 12, color: "#5a6478" },
  clearFile: {
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.1)",
    color: "#8892a4",
    borderRadius: 6,
    padding: "4px 8px",
    cursor: "pointer",
    marginLeft: 8,
  },
  statsBar: {
    display: "flex",
    gap: 16,
    fontSize: 12,
    color: "#5a6478",
    marginBottom: 16,
  },
  errorBox: {
    background: "#f8717120",
    border: "1px solid #f8717140",
    color: "#f87171",
    borderRadius: 10,
    padding: "12px 16px",
    fontSize: 14,
    marginBottom: 16,
  },
  btn: {
    width: "100%",
    padding: "16px",
    background: "#00e5a0",
    color: "#0a0b0f",
    border: "none",
    borderRadius: 12,
    fontSize: 16,
    fontWeight: 700,
    cursor: "pointer",
    letterSpacing: "0.3px",
    transition: "all 0.2s",
  },
  btnDisabled: { opacity: 0.6, cursor: "not-allowed" },
  spinner: { display: "inline-block" },
  resultCard: {
    background: "rgba(0,229,160,0.04)",
    border: "1px solid rgba(0,229,160,0.2)",
    borderRadius: 20,
    padding: 32,
    animation: "fadeIn 0.3s ease",
  },
  resultHeader: {
    display: "flex",
    alignItems: "center",
    gap: 20,
    marginBottom: 28,
  },
  resultIcon: { fontSize: 48 },
  resultLabel: { fontSize: 12, color: "#5a6478", textTransform: "uppercase", letterSpacing: "2px", marginBottom: 4 },
  resultCategory: { fontSize: 28, fontWeight: 800, color: "#00e5a0", letterSpacing: "-0.5px" },
  confidenceSection: { marginBottom: 24 },
  confRow: { display: "flex", justifyContent: "space-between", marginBottom: 8 },
  confLabel: { fontSize: 13, color: "#8892a4" },
  confValue: { fontSize: 13, fontWeight: 600 },
  confBar: {
    height: 6,
    background: "rgba(255,255,255,0.08)",
    borderRadius: 3,
    overflow: "hidden",
  },
  confFill: {
    height: "100%",
    borderRadius: 3,
    transition: "width 0.8s ease",
  },
  altSection: {
    borderTop: "1px solid rgba(255,255,255,0.06)",
    paddingTop: 20,
    marginBottom: 20,
  },
  altTitle: { fontSize: 12, color: "#5a6478", textTransform: "uppercase", letterSpacing: "2px", marginBottom: 12 },
  altRow: {
    display: "flex",
    justifyContent: "space-between",
    padding: "8px 0",
    fontSize: 14,
    borderBottom: "1px solid rgba(255,255,255,0.03)",
    color: "#c8d0dc",
  },
  altScore: { color: "#8892a4", fontVariantNumeric: "tabular-nums" },
  metaRow: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    fontSize: 12,
    color: "#5a6478",
    borderTop: "1px solid rgba(255,255,255,0.06)",
    paddingTop: 16,
    flexWrap: "wrap",
    gap: 8,
  },
  pipeline: {
    maxWidth: 960,
    margin: "0 auto 60px",
    padding: "0 32px",
    position: "relative",
    zIndex: 1,
  },
  pipelineTitle: {
    fontSize: 20,
    fontWeight: 700,
    marginBottom: 24,
    color: "#c8d0dc",
    letterSpacing: "-0.5px",
  },
  pipelineSteps: {
    display: "flex",
    alignItems: "center",
    gap: 0,
    overflowX: "auto",
    padding: "4px 0",
  },
  pipelineStep: {
    position: "relative",
    background: "rgba(255,255,255,0.03)",
    border: "1px solid rgba(255,255,255,0.07)",
    borderRadius: 14,
    padding: "20px 24px",
    textAlign: "center",
    minWidth: 130,
    flex: 1,
  },
  pipelineStepIcon: { fontSize: 24, display: "block", marginBottom: 8 },
  pipelineStepLabel: { fontWeight: 700, fontSize: 14, color: "#e8eaf0", marginBottom: 4 },
  pipelineStepDesc: { fontSize: 11, color: "#5a6478" },
  pipelineArrow: {
    color: "#00e5a0",
    fontSize: 20,
    padding: "0 8px",
    flexShrink: 0,
  },
  footer: {
    textAlign: "center",
    padding: "24px 32px",
    fontSize: 12,
    color: "#2d3344",
    borderTop: "1px solid rgba(255,255,255,0.04)",
    position: "relative",
    zIndex: 1,
  },
};

export default App;
