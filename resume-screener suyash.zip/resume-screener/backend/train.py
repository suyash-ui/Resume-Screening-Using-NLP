"""
train.py - Train Resume Classification Models
Run: python train.py
Requires: UpdatedResumeDataSet.csv in ../data/ directory
"""

import os
import re
import pickle
import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.multiclass import OneVsRestClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(BASE_DIR, "..", "data", "UpdatedResumeDataSet.csv")
MODEL_DIR = os.path.join(BASE_DIR, "..", "models")
os.makedirs(MODEL_DIR, exist_ok=True)

# ─── Text Cleaning ─────────────────────────────────────────────────────────────

def clean_resume(txt: str) -> str:
    text = re.sub(r'http\S+', ' ', txt)
    text = re.sub(r'RT|cc', ' ', text)
    text = re.sub(r'#\S+', ' ', text)
    text = re.sub(r'@\S+', ' ', text)
    text = re.sub(r'[^\x00-\x7f]', ' ', text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


# ─── Training Pipeline ─────────────────────────────────────────────────────────

def train():
    print("=" * 60)
    print("Resume Screening System - Model Training")
    print("=" * 60)

    # 1. Load Data
    print("\n[1/8] Loading dataset...")
    if not os.path.exists(DATA_PATH):
        raise FileNotFoundError(
            f"Dataset not found at {DATA_PATH}\n"
            "Download from: https://www.kaggle.com/datasets/gauravduttakiit/resume-dataset\n"
            "Place as: data/UpdatedResumeDataSet.csv"
        )
    df = pd.read_csv(DATA_PATH)
    print(f"     Shape: {df.shape}")
    print(f"     Columns: {df.columns.tolist()}")
    print(f"     Categories: {df['Category'].nunique()} unique job roles")

    # 2. EDA
    print("\n[2/8] Exploratory Data Analysis...")
    print(df['Category'].value_counts().to_string())

    # 3. Oversampling to balance classes
    print("\n[3/8] Balancing classes via oversampling...")
    max_size = df['Category'].value_counts().max()
    balanced_df = df.groupby('Category').apply(
        lambda x: x.sample(max_size, replace=True)
    ).reset_index(drop=True)
    df = balanced_df.sample(frac=1).reset_index(drop=True)
    print(f"     Balanced dataset: {df.shape} ({df['Category'].nunique()} × {max_size})")

    # 4. Clean text
    print("\n[4/8] Cleaning resume text...")
    df['Resume'] = df['Resume'].apply(clean_resume)
    print("     Text cleaning complete")

    # 5. Label Encoding
    print("\n[5/8] Encoding labels...")
    le = LabelEncoder()
    le.fit(df['Category'])
    df['Category'] = le.transform(df['Category'])
    print(f"     Encoded {len(le.classes_)} categories: {list(le.classes_[:5])} ...")

    # 6. TF-IDF
    print("\n[6/8] TF-IDF feature extraction...")
    tfidf = TfidfVectorizer(stop_words='english')
    tfidf.fit(df['Resume'])
    X = tfidf.transform(df['Resume'])
    y = df['Category']
    print(f"     Vocabulary size: {len(tfidf.vocabulary_)} terms")
    print(f"     Feature matrix: {X.shape}")

    # 7. Train-Test Split
    print("\n[7/8] Splitting train/test (80/20)...")
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    print(f"     Train: {X_train.shape}, Test: {X_test.shape}")

    # 8. Train & Evaluate Models
    print("\n[8/8] Training and evaluating models...")
    models = {
        "SVC (OneVsRest)":       OneVsRestClassifier(SVC(probability=True, kernel='linear')),
        "KNN (OneVsRest)":       OneVsRestClassifier(KNeighborsClassifier()),
        "Random Forest":         OneVsRestClassifier(RandomForestClassifier(n_estimators=100)),
        "Logistic Regression":   OneVsRestClassifier(LogisticRegression(max_iter=1000)),
        "Gaussian Naive Bayes":  OneVsRestClassifier(GaussianNB()),
    }

    results = {}
    best_model = None
    best_acc = 0
    best_name = ""

    for name, model in models.items():
        print(f"\n  → Training {name}...")
        if "Naive Bayes" in name:
            model.fit(X_train.toarray(), y_train)
            y_pred = model.predict(X_test.toarray())
        else:
            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)
        
        acc = accuracy_score(y_test, y_pred)
        results[name] = {"accuracy": acc, "model": model, "predictions": y_pred}
        print(f"     Accuracy: {acc:.4f} ({acc*100:.2f}%)")
        
        if acc > best_acc:
            best_acc = acc
            best_model = model
            best_name = name

    # Print best model report
    print(f"\n{'='*60}")
    print(f"Best Model: {best_name} ({best_acc*100:.2f}% accuracy)")
    print(f"{'='*60}")
    best_preds = results[best_name]["predictions"]
    print(classification_report(y_test, best_preds, target_names=le.classes_))

    # Save accuracy comparison
    _save_accuracy_plot(results)

    # Save SVC confusion matrix
    svc_name = "SVC (OneVsRest)"
    if svc_name in results:
        _save_confusion_matrix(y_test, results[svc_name]["predictions"], le)

    # Serialize models (use SVC as primary)
    svc_model = results.get("SVC (OneVsRest)", {}).get("model", best_model)
    
    print("\nSaving models...")
    with open(os.path.join(MODEL_DIR, "tfidf.pkl"), "wb") as f:
        pickle.dump(tfidf, f)
    with open(os.path.join(MODEL_DIR, "clf.pkl"), "wb") as f:
        pickle.dump(svc_model, f)
    with open(os.path.join(MODEL_DIR, "encoder.pkl"), "wb") as f:
        pickle.dump(le, f)

    # Save results summary
    summary = {name: {"accuracy": v["accuracy"]} for name, v in results.items()}
    with open(os.path.join(MODEL_DIR, "results.pkl"), "wb") as f:
        pickle.dump(summary, f)

    print("\n✅ Models saved to models/")
    print(f"   - tfidf.pkl     ({len(tfidf.vocabulary_)} terms)")
    print(f"   - clf.pkl       (SVC, {best_acc*100:.2f}% accuracy)")
    print(f"   - encoder.pkl   ({len(le.classes_)} categories)")
    print(f"   - results.pkl   (benchmark results)")
    return True


def _save_accuracy_plot(results: dict):
    names = list(results.keys())
    accs = [v["accuracy"] * 100 for v in results.values()]
    
    fig, ax = plt.subplots(figsize=(10, 5))
    colors = ['#2ecc71' if a == max(accs) else '#3498db' for a in accs]
    bars = ax.bar(names, accs, color=colors, edgecolor='white', linewidth=0.5)
    ax.set_ylim(80, 105)
    ax.set_ylabel("Accuracy (%)", fontsize=12)
    ax.set_title("Classifier Accuracy Comparison", fontsize=14, fontweight='bold')
    ax.set_xticklabels(names, rotation=20, ha='right')
    for bar, acc in zip(bars, accs):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3,
                f"{acc:.1f}%", ha='center', va='bottom', fontsize=10)
    plt.tight_layout()
    plot_path = os.path.join(MODEL_DIR, "accuracy_comparison.png")
    plt.savefig(plot_path, dpi=120, bbox_inches='tight')
    plt.close()
    print(f"  Saved: {plot_path}")


def _save_confusion_matrix(y_test, y_pred, le):
    # Only plot a subset if too many classes
    cm = confusion_matrix(y_test, y_pred)
    n = min(10, len(le.classes_))  # show first 10 classes
    
    fig, ax = plt.subplots(figsize=(12, 10))
    sns.heatmap(cm[:n, :n], annot=True, fmt='d', cmap='Blues',
                xticklabels=le.classes_[:n], yticklabels=le.classes_[:n], ax=ax)
    ax.set_title("SVC Confusion Matrix (Top 10 Categories)", fontsize=14)
    ax.set_xlabel("Predicted", fontsize=12)
    ax.set_ylabel("Actual", fontsize=12)
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    plot_path = os.path.join(MODEL_DIR, "confusion_matrix.png")
    plt.savefig(plot_path, dpi=120, bbox_inches='tight')
    plt.close()
    print(f"  Saved: {plot_path}")


if __name__ == "__main__":
    train()
