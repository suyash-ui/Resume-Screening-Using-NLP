"""
Resume Screening System - FastAPI Backend
NLP + Machine Learning based resume classification
"""

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import pickle
import re
import os
import io
import logging
from typing import Optional
import numpy as np

# Optional file parsing imports
try:
    import PyPDF2
    HAS_PYPDF2 = True
except ImportError:
    HAS_PYPDF2 = False

try:
    import docx2txt
    HAS_DOCX2TXT = True
except ImportError:
    HAS_DOCX2TXT = False

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Resume Screening API",
    description="NLP-based Resume Classification System using TF-IDF + SVC",
    version="1.0.0"
)

# CORS for React frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:5173", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── Model Loading ────────────────────────────────────────────────────────────

MODEL_DIR = os.path.join(os.path.dirname(__file__), "..", "models")

tfidf = None
clf = None
encoder = None

def load_models():
    global tfidf, clf, encoder
    try:
        tfidf_path = os.path.join(MODEL_DIR, "tfidf.pkl")
        clf_path = os.path.join(MODEL_DIR, "clf.pkl")
        encoder_path = os.path.join(MODEL_DIR, "encoder.pkl")

        if all(os.path.exists(p) for p in [tfidf_path, clf_path, encoder_path]):
            with open(tfidf_path, "rb") as f:
                tfidf = pickle.load(f)
            with open(clf_path, "rb") as f:
                clf = pickle.load(f)
            with open(encoder_path, "rb") as f:
                encoder = pickle.load(f)
            logger.info("✅ Models loaded successfully from disk")
            return True
        else:
            logger.warning("⚠️  Saved models not found. Will use demo mode.")
            return False
    except Exception as e:
        logger.error(f"❌ Model loading failed: {e}")
        return False


# ─── Text Cleaning ────────────────────────────────────────────────────────────

def clean_resume(text: str) -> str:
    """Clean resume text using regex patterns."""
    text = re.sub(r'http\S+', ' ', text)          # Remove URLs
    text = re.sub(r'RT|cc', ' ', text)             # Remove RT/cc
    text = re.sub(r'#\S+', ' ', text)              # Remove hashtags
    text = re.sub(r'@\S+', ' ', text)              # Remove mentions
    text = re.sub(r'[^\x00-\x7f]', ' ', text)     # Remove non-ASCII
    text = re.sub(r'\s+', ' ', text)               # Collapse whitespace
    return text.strip()


# ─── Prediction Logic ─────────────────────────────────────────────────────────

# Demo categories for when models aren't loaded
DEMO_CATEGORIES = [
    "Data Science", "Java Developer", "Python Developer", "Web Designing",
    "HR", "Testing", "DevOps Engineer", "Hadoop", "Sales", "Mechanical Engineer",
    "ETL Developer", "Arts", "Database", "Health and Fitness", "PMO",
    "Electrical Engineering", "Business Analyst", "DotNet Developer",
    "Automation Testing", "Network Security Engineer", "Civil Engineer",
    "SAP Developer", "Advocate", "Blockchain", "Operations Manager"
]

# Keyword-based demo predictor
CATEGORY_KEYWORDS = {
    "Data Science": ["machine learning", "deep learning", "data science", "neural network", "tensorflow", "pytorch", "pandas", "numpy", "statistics", "ai", "artificial intelligence", "computer vision", "nlp"],
    "Java Developer": ["java", "spring boot", "hibernate", "maven", "gradle", "j2ee", "jvm", "microservices", "spring framework"],
    "Python Developer": ["python", "django", "flask", "fastapi", "celery", "sqlalchemy", "pytest"],
    "Web Designing": ["html", "css", "javascript", "react", "angular", "vue", "bootstrap", "tailwind", "figma", "ux", "ui"],
    "HR": ["human resources", "recruitment", "talent acquisition", "onboarding", "payroll", "employee relations", "hr"],
    "Testing": ["selenium", "testing", "qa", "quality assurance", "test cases", "jira", "bug", "automation testing"],
    "DevOps Engineer": ["devops", "docker", "kubernetes", "jenkins", "ci/cd", "aws", "azure", "terraform", "ansible"],
    "Hadoop": ["hadoop", "hive", "spark", "mapreduce", "hdfs", "pig", "big data"],
    "Sales": ["sales", "revenue", "crm", "client", "business development", "target", "lead generation"],
    "Mechanical Engineer": ["mechanical", "autocad", "solidworks", "manufacturing", "cad", "cam", "thermodynamics"],
    "Blockchain": ["blockchain", "ethereum", "solidity", "smart contract", "web3", "cryptocurrency", "bitcoin"],
    "Network Security Engineer": ["network security", "firewall", "penetration testing", "cybersecurity", "ethical hacking", "cisco"],
    "Civil Engineer": ["civil", "structural", "construction", "autocad", "surveying", "concrete"],
    "DotNet Developer": ["c#", ".net", "asp.net", "mvc", "entity framework", "visual studio", "wpf"],
    "Database": ["sql", "mysql", "postgresql", "oracle", "mongodb", "nosql", "database administration", "dba"],
}

def demo_predict(text: str) -> dict:
    """Keyword-based prediction for demo mode."""
    text_lower = text.lower()
    scores = {}
    for category, keywords in CATEGORY_KEYWORDS.items():
        score = sum(1 for kw in keywords if kw in text_lower)
        if score > 0:
            scores[category] = score

    if not scores:
        return {"category": "Other", "confidence": 0.3, "mode": "demo"}

    sorted_scores = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    top_category = sorted_scores[0][0]
    top_score = sorted_scores[0][1]
    confidence = min(0.95, 0.5 + (top_score * 0.1))

    top_3 = [{"category": cat, "score": round(sc / max(scores.values()), 3)}
              for cat, sc in sorted_scores[:3]]

    return {
        "category": top_category,
        "confidence": round(confidence, 3),
        "mode": "demo",
        "top_predictions": top_3
    }


def ml_predict(text: str) -> dict:
    """Full ML pipeline prediction using trained models."""
    cleaned = clean_resume(text)
    vectorized = tfidf.transform([cleaned])
    
    # Get probabilities if available
    if hasattr(clf, "predict_proba"):
        probs = clf.predict_proba(vectorized)[0]
        top_indices = np.argsort(probs)[::-1][:3]
        top_predictions = [
            {"category": encoder.inverse_transform([i])[0], "score": round(float(probs[i]), 3)}
            for i in top_indices if probs[i] > 0.01
        ]
        confidence = float(probs[top_indices[0]])
    else:
        predicted_label = clf.predict(vectorized)
        top_predictions = []
        confidence = 1.0

    predicted_label = clf.predict(vectorized)
    category = encoder.inverse_transform(predicted_label)[0]

    return {
        "category": category,
        "confidence": round(confidence, 3),
        "mode": "ml",
        "top_predictions": top_predictions if top_predictions else [{"category": category, "score": 1.0}]
    }


def predict(text: str) -> dict:
    if tfidf and clf and encoder:
        return ml_predict(text)
    return demo_predict(text)


# ─── Schemas ──────────────────────────────────────────────────────────────────

class ResumeTextInput(BaseModel):
    text: str

class TrainRequest(BaseModel):
    force_retrain: bool = False


# ─── Routes ───────────────────────────────────────────────────────────────────

@app.on_event("startup")
async def startup_event():
    load_models()
    logger.info("🚀 Resume Screening API started")


@app.get("/")
def root():
    return {
        "message": "Resume Screening API",
        "version": "1.0.0",
        "models_loaded": tfidf is not None,
        "endpoints": ["/predict/text", "/predict/file", "/train", "/health", "/categories"]
    }


@app.get("/health")
def health():
    return {
        "status": "healthy",
        "models_loaded": tfidf is not None,
        "mode": "ml" if tfidf is not None else "demo"
    }


@app.get("/categories")
def get_categories():
    if encoder:
        categories = list(encoder.classes_)
    else:
        categories = DEMO_CATEGORIES
    return {"categories": categories, "count": len(categories)}


@app.post("/predict/text")
def predict_from_text(input_data: ResumeTextInput):
    """Predict job category from raw resume text."""
    if not input_data.text.strip():
        raise HTTPException(status_code=400, detail="Resume text cannot be empty")
    
    if len(input_data.text) < 50:
        raise HTTPException(status_code=400, detail="Resume text too short (minimum 50 characters)")

    result = predict(input_data.text)
    result["word_count"] = len(input_data.text.split())
    result["char_count"] = len(input_data.text)
    return result


@app.post("/predict/file")
async def predict_from_file(file: UploadFile = File(...)):
    """Predict job category from uploaded resume file (PDF, DOCX, TXT)."""
    allowed_types = ["application/pdf", "text/plain",
                     "application/vnd.openxmlformats-officedocument.wordprocessingml.document"]
    
    content = await file.read()
    filename = file.filename.lower()
    text = ""

    try:
        if filename.endswith(".pdf"):
            if not HAS_PYPDF2:
                raise HTTPException(status_code=400, detail="PDF support not installed (pip install PyPDF2)")
            reader = PyPDF2.PdfReader(io.BytesIO(content))
            for page in reader.pages:
                text += page.extract_text() + "\n"

        elif filename.endswith(".docx"):
            if not HAS_DOCX2TXT:
                raise HTTPException(status_code=400, detail="DOCX support not installed (pip install docx2txt)")
            text = docx2txt.process(io.BytesIO(content))

        elif filename.endswith(".txt"):
            text = content.decode("utf-8", errors="replace")

        else:
            raise HTTPException(status_code=400, detail=f"Unsupported file type: {filename}")

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"File parsing failed: {str(e)}")

    if not text.strip():
        raise HTTPException(status_code=400, detail="Could not extract text from file")

    result = predict(text)
    result["filename"] = file.filename
    result["word_count"] = len(text.split())
    result["char_count"] = len(text)
    return result


@app.post("/train")
def train_model(request: TrainRequest):
    """Train or retrain the ML models from the dataset."""
    import subprocess
    import sys
    
    trainer_path = os.path.join(os.path.dirname(__file__), "train.py")
    if not os.path.exists(trainer_path):
        raise HTTPException(status_code=404, detail="Training script not found")
    
    try:
        result = subprocess.run(
            [sys.executable, trainer_path],
            capture_output=True, text=True, timeout=300
        )
        if result.returncode == 0:
            load_models()
            return {"status": "success", "message": "Models trained and loaded", "output": result.stdout}
        else:
            raise HTTPException(status_code=500, detail=f"Training failed: {result.stderr}")
    except subprocess.TimeoutExpired:
        raise HTTPException(status_code=408, detail="Training timed out (>5 min)")


@app.post("/clean")
def clean_text_endpoint(input_data: ResumeTextInput):
    """Preview cleaned resume text."""
    cleaned = clean_resume(input_data.text)
    return {
        "original_length": len(input_data.text),
        "cleaned_length": len(cleaned),
        "cleaned_text": cleaned[:1000]
    }
